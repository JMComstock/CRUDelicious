﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CRUDelicious.Models;
using CRUDelicious.Contexts;

namespace CRUDelicious.Controllers
{
    public class HomeController : Controller
    {
        private HomeContext dbContext;
        public HomeController(HomeContext context)
        {
            dbContext = context;
        }

        [HttpGet("dishes")]
        public IActionResult Dishes()
        {
            List<Dish> AllDishes = dbContext.Dishes.ToList();
            return View(AllDishes);
        }
        public IActionResult Index()
        {
            List<Dish> AllDishes = dbContext.Dishes.ToList();
            return View(AllDishes);
        }

        [HttpGet("new")]
        public IActionResult newDish()
        {
            return View("AddDish");
        }

        [HttpPost("create")]
        public IActionResult Create(Dish newDish)
        {
            if(ModelState.IsValid)
            {
                dbContext.Dishes.Add(newDish);
                dbContext.SaveChanges();
                List<Dish> AllDishes = dbContext.Dishes.ToList();
                return View("Index", AllDishes);
            }
            else
            {
                return View("AddDish");
            }
        }

        [HttpGet("dish/{dishId}")]
        public IActionResult OneDish(int dishId)
        {
            Dish Show = dbContext.Dishes.FirstOrDefault( w => w.DishId == dishId);
            return View(Show);
        }

        [HttpGet("edit/{dishId}")]
        public IActionResult EditDish(int dishId)
        {
            Dish Edit = dbContext.Dishes.FirstOrDefault( w => w.DishId == dishId);
            return View(Edit);
        }

        [HttpPost("update/{dishId}")]
        public IActionResult UpdateWaffle(int dishId, Dish update)
        {
            if(ModelState.IsValid)
            {
                Dish DbWaffle = dbContext.Dishes.FirstOrDefault( w => w.DishId == dishId);

                DbWaffle.Chef = update.Chef;
                DbWaffle.Name = update.Name;
                DbWaffle.Calories = update.Calories;
                DbWaffle.Tastiness = update.Tastiness;
                DbWaffle.Description = update.Description;
                DbWaffle.UpdatedAt = DateTime.Now;
                dbContext.SaveChanges();
                return Redirect($"/dish/{dishId}");
            }
            else
            {
                update.DishId = dishId;
                return View("EditDish",update);
            }
        }

        [HttpGet("delete/{dishId}")]
        public IActionResult DeleteDish(int dishId)
        {
            //Query for a single dish from the Context object
            Dish RetrieveDish = dbContext.Dishes.SingleOrDefault(dish => dish.DishId == dishId);
            //pass the object that was queried for to .Remove() on Dishes
            dbContext.Dishes.Remove(RetrieveDish);
            //.SaveChanges() will remove the corresponding row representing this Dish from DB
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
